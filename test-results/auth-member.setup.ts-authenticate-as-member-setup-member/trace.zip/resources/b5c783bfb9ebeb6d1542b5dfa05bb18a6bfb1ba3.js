(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/layout/runtime-error-capture.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RuntimeErrorCapture",
    ()=>RuntimeErrorCapture,
    "reportRuntimeError",
    ()=>reportRuntimeError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
const seenErrors = new Set();
function makeSignature(payload) {
    return JSON.stringify({
        source: payload.source,
        category: payload.category,
        message: payload.message,
        stack: payload.stack ?? null,
        metadata: payload.metadata ?? null
    });
}
function reportRuntimeError(payload) {
    const signature = makeSignature(payload);
    if (seenErrors.has(signature)) {
        return;
    }
    seenErrors.add(signature);
    const body = JSON.stringify(payload);
    if (typeof navigator !== 'undefined' && typeof navigator.sendBeacon === 'function') {
        const blob = new Blob([
            body
        ], {
            type: 'application/json'
        });
        navigator.sendBeacon('/api/observability/errors', blob);
        return;
    }
    void fetch('/api/observability/errors', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body,
        keepalive: true
    }).catch(()=>{
    // Ignore transport failures for telemetry.
    });
}
function normalizeUnknownError(reason) {
    if (reason instanceof Error) {
        return {
            message: reason.message,
            stack: reason.stack ?? null
        };
    }
    if (typeof reason === 'string') {
        return {
            message: reason,
            stack: null
        };
    }
    return {
        message: 'Unknown runtime error',
        stack: null
    };
}
function RuntimeErrorCapture() {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RuntimeErrorCapture.useEffect": ()=>{
            const handleError = {
                "RuntimeErrorCapture.useEffect.handleError": (event)=>{
                    reportRuntimeError({
                        source: 'client',
                        category: 'window.error',
                        message: event.message || 'Unhandled client error',
                        stack: event.error instanceof Error ? event.error.stack ?? null : null,
                        metadata: {
                            filename: event.filename || null,
                            line: typeof event.lineno === 'number' ? event.lineno : null,
                            column: typeof event.colno === 'number' ? event.colno : null
                        }
                    });
                }
            }["RuntimeErrorCapture.useEffect.handleError"];
            const handleUnhandledRejection = {
                "RuntimeErrorCapture.useEffect.handleUnhandledRejection": (event)=>{
                    const normalized = normalizeUnknownError(event.reason);
                    reportRuntimeError({
                        source: 'client',
                        category: 'unhandledrejection',
                        message: normalized.message,
                        stack: normalized.stack
                    });
                }
            }["RuntimeErrorCapture.useEffect.handleUnhandledRejection"];
            window.addEventListener('error', handleError);
            window.addEventListener('unhandledrejection', handleUnhandledRejection);
            return ({
                "RuntimeErrorCapture.useEffect": ()=>{
                    window.removeEventListener('error', handleError);
                    window.removeEventListener('unhandledrejection', handleUnhandledRejection);
                }
            })["RuntimeErrorCapture.useEffect"];
        }
    }["RuntimeErrorCapture.useEffect"], []);
    return null;
}
_s(RuntimeErrorCapture, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = RuntimeErrorCapture;
var _c;
__turbopack_context__.k.register(_c, "RuntimeErrorCapture");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=components_layout_runtime-error-capture_tsx_03kep61._.js.map