(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_next_dist_079ko4n._.js","static/chunks/components_layout_runtime-error-capture_tsx_03kep61._.js","static/chunks/app_globals_0jn8.0u.css"],
    source: "dynamic"
});
